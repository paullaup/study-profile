﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcurementSystem
{
    internal abstract class PurchaseOrder
    {

        public abstract int getPONumber();

    }
}
