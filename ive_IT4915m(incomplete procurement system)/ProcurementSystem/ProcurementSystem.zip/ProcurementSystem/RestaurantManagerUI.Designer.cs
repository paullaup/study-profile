﻿namespace ProcurementSystem
{
    partial class RestaurantManagerUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemRequestManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.myRequestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem,
            this.MenuItemRequestManagement});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1009, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logoutToolStripMenuItem.Text = "logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MenuItemRequestManagement
            // 
            this.MenuItemRequestManagement.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myRequestToolStripMenuItem});
            this.MenuItemRequestManagement.Name = "MenuItemRequestManagement";
            this.MenuItemRequestManagement.Size = new System.Drawing.Size(142, 20);
            this.MenuItemRequestManagement.Text = "RequestManagement";
            // 
            // myRequestToolStripMenuItem
            // 
            this.myRequestToolStripMenuItem.Name = "myRequestToolStripMenuItem";
            this.myRequestToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.myRequestToolStripMenuItem.Text = "My request";
            this.myRequestToolStripMenuItem.Click += new System.EventHandler(this.myRequestToolStripMenuItem_Click);
            // 
            // RestaurantManagerUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 681);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "RestaurantManagerUI";
            this.Text = "RestaurantManager";
            this.Load += new System.EventHandler(this.RestaurantManager_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItemRequestManagement;
        private System.Windows.Forms.ToolStripMenuItem myRequestToolStripMenuItem;
    }
}