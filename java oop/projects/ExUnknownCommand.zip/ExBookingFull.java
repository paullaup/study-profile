public class ExBookingFull extends Exception {
    
    public ExBookingFull() {
        super("There is no available set of this equipment for the command.");
    }

}
