// public class Borrow extends Reservation {
    
//     public Borrow(Member member, Day starDay, Day lastDay) {
//         super(member, starDay, lastDay);
//     }

//     @Override
//     public String toString() {
//         String s = String.format("%s borrows %s for %s to %s", member, set, starDay, lastDay);
//         return s;
//     }

//     @Override
//     public String getMemberReservationString() {
//         return String.format("borrows %s for %s to %s", set, starDay, lastDay);
//     }

//     @Override
//     public String getEquipmentStatusString() {
//         return String.format("%s borrows for %s to %s", member, starDay, lastDay);
//     }

    

// }
