// public class Request extends Reservation {

//     public Request(Member member, Day starDay, Day lastDay) {
//         super(member, starDay, lastDay);
//     }

//     @Override
//     public String toString() {
//         String s = String.format("%s requests %s for %s", member, set, getPeriodString());
//         return s;
//     }

//     @Override
//     public String getMemberReservationString() {
//         return String.format("requests %s for %s", set, getPeriodString());
//     }

//     @Override
//     public String getEquipmentStatusString() {
//         return String.format("%s requests for %s", member, getPeriodString());
//     }


    
// }
