public class ExArgumentInsufficient extends Exception{

    public ExArgumentInsufficient() {
        super("Insufficient command arguments.");
    }

}