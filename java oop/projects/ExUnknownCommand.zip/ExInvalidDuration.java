public class ExInvalidDuration extends Exception {
    public ExInvalidDuration(String message) {
        super(message);
    }
}
