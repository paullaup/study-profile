public class ExMemberNotFound extends Exception {
    
    public ExMemberNotFound() {
        super("Member not found.");
    }

}
